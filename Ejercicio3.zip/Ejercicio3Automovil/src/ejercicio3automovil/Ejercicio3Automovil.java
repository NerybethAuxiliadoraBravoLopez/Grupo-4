
package ejercicio3automovil;

import ejercicio3automovil.Automovil.Color;
import ejercicio3automovil.Automovil.TipoAutomovil;
import ejercicio3automovil.Automovil.TipoCombustible;


public class Ejercicio3Automovil {

    
    public static void main(String[] args) {
        
        
        Automovil auto = new Automovil("Toyota", 2022, 2.0,
                TipoCombustible.GASOLINA, TipoAutomovil.SUV,
                4, 5, 200, Color.NEGRO);

        auto.setVelocidadActual(100);
        System.out.println("Velocidad: " + auto.getVelocidadActual());

        auto.acelerar(20);
        System.out.println("Velocidad: " + auto.getVelocidadActual());

        auto.desacelerar(50);
        System.out.println("Velocidad: " + auto.getVelocidadActual());

        auto.frenar();
        System.out.println("Velocidad: " + auto.getVelocidadActual());
    
    }
    
}
