
package ejercicio3automovil;

/**
 *
 * Nerybeth Bravo López
 */
public class Automovil {
    
    enum TipoCombustible {
        GASOLINA,
        BIOETANOL,
        DIESEL,
        BIODIESEL,
        GAS_NATURAL
    }

    enum TipoAutomovil {
        CIUDAD,
        SUBCOMPACTO,
        COMPACTO,
        FAMILIAR,
        EJECUTIVO,
        SUV
    }

    enum Color {
        BLANCO,
        NEGRO,
        ROJO,
        NARANJA,
        AMARILLO,
        VERDE,
        AZUL,
        VIOLETA
    }
    
    
     String marca;
    int modelo;
    double motor;
    TipoCombustible combustible;
    TipoAutomovil tipo;
    int puertas;
    int asientos;
    int velocidadMax;
    Color color;
    int velocidadActual;

    
     public Automovil(String marca, int modelo, double motor,
                     TipoCombustible combustible, TipoAutomovil tipo,
                     int puertas, int asientos, int velocidadMax, Color color) {

        this.marca = marca;
        this.modelo = modelo;
        this.motor = motor;
        this.combustible = combustible;
        this.tipo = tipo;
        this.puertas = puertas;
        this.asientos = asientos;
        this.velocidadMax = velocidadMax;
        this.color = color;
        this.velocidadActual = 0;
    }
     
     public int getVelocidadActual() {
        return velocidadActual;
    }

    public void setVelocidadActual(int velocidadActual) {
        this.velocidadActual = velocidadActual;
    }

    // Acelerar
    public void acelerar(int incremento) {
        if (velocidadActual + incremento > velocidadMax) {
            System.out.println("No se puede superar la velocidad máxima.");
        } else {
            velocidadActual += incremento;
        }
    }

    public void desacelerar(int decremento) {
        if (velocidadActual - decremento < 0) {
            System.out.println("No se puede tener velocidad negativa.");
        } else {
            velocidadActual -= decremento;
        }
    }

     public void frenar() {
        velocidadActual = 0;
    }
     
      public double calcularTiempoLlegada(double distancia) {
        return distancia / velocidadActual;
    }
      
        public void mostrarDatos() {
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Velocidad actual: " + velocidadActual);
    }
    
     
    
}
