
package ejercicio2planeta;

import ejercicio2planeta.Planeta.TipoPlaneta;


public class Ejercicio2Planeta {

    
    public static void main(String[] args) {
        Planeta tierra = new Planeta("Tierra", 1, 5.97E24, 1.08E12,
                12742, 150, TipoPlaneta.TERRESTRE, true);
                tierra.imprimir();

                Planeta jupiter = new Planeta("Jupiter", 79, 1.90E27, 1.43E15,
                139820, 778, TipoPlaneta.GASEOSO, true);
                        jupiter.imprimir();

                
                
    }
    
}
