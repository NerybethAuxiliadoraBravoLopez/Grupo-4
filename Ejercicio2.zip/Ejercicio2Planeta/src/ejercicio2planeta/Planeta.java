
package ejercicio2planeta;

/**
 *
 * Nerybeth Bravo López
 */
public class Planeta {
    
    enum TipoPlaneta {
        GASEOSO,
        TERRESTRE,
        ENANO,
    }

   
    String nombre = null;
    int cantidadSatelites = 0;
    double masa = 0;
    double volumen = 0;
    int diametro = 0;
    int distanciaSol = 0;
    TipoPlaneta tipoPlaneta;
    boolean observable = false;
    
    public Planeta(String nombre, int cantidadSatelites, double masa, double volumen,
                   int diametro, int distanciaSol, TipoPlaneta tipoPlaneta, boolean observable) {

        this.nombre = nombre;
        this.cantidadSatelites = cantidadSatelites;
        this.masa = masa;
        this.volumen = volumen;
        this.diametro = diametro;
        this.distanciaSol = distanciaSol;
        this.tipoPlaneta = tipoPlaneta;
        this.observable = observable;
    }
    
     public double calcularDensidad() {
        return masa / volumen;
    }

   
    public boolean esExterior() {
        double UA = 149597870;
        double distanciaUA = (distanciaSol * 1000000.0) / UA;
        return distanciaUA > 3.4;
    }
    
     public void imprimir() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Satélites: " + cantidadSatelites);
        System.out.println("Masa: " + masa);
        System.out.println("Volumen: " + volumen);
        System.out.println("Diámetro: " + diametro);
        System.out.println("Distancia al Sol: " + distanciaSol + " millones km");
        System.out.println("Tipo: " + tipoPlaneta);
        System.out.println("Observable: " + observable);
        System.out.println("Densidad: " + calcularDensidad());
        System.out.println("¿Es planeta exterior?: " + esExterior());
      
    }
}
