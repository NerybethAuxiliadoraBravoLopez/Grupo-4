//Nerybeth Bravo López
package ejercicio1.persona;


public class Persona {
    String cedula;
    String nombre;
    String apellido;
    int añonacimiento;
    String paisnacmiento;
    char genero;
    
    Persona (String ced, String nom, String ape, int año, String pais, char gen) {
        this.cedula=ced;
        this.nombre=nom;
        this.apellido=ape;
        this.añonacimiento=año;
        this.paisnacmiento=pais;
        this.genero=gen;
        
    
    };
    
    void ImprimirPerona(){
    System.out.println("Nombre de la perona:"+ nombre);
    System.out.println("Cedula:"+ cedula );
    System.out.println("Apellidos:" + apellido);
    System.out.println("Año de nacimiento:" + añonacimiento);
    System.out.println("Pais de nacimiento:" + paisnacmiento);
    System.out.println("Genero:" + genero);
    }
    
    int calcularEdad(){
           return 2026-añonacimiento; 
 
        
    }
    
}
