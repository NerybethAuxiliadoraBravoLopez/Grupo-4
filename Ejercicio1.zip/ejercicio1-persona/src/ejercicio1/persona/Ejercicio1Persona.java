
package ejercicio1.persona;


public class Ejercicio1Persona {

    
    public static void main(String[] args) {
        Persona p1= new Persona("0001", "Jorge", "Ulloa", 1995,"Argentina", 'M');
        p1.ImprimirPerona();
        System.out.println("Edad:" + p1.calcularEdad());
        
        Persona p2=new Persona("0002", "Manuel", "López", 2000, "Nicaragua", 'M');
        p2.ImprimirPerona();
        System.out.println("Edad:" + p2.calcularEdad());
        
    }
    
}
