public class Rectangulo {
    int base;
    int altura;

    // Constructor
    public Rectangulo(int base, int altura) {
        this.base = base;
        this.altura = altura;
    }

    // Método con retorno: calcula el área del rectángulo
    public double calcularArea() {
        return base * altura;
    }

    // Método con retorno: calcula el perímetro del rectángulo
    public double calcularPerimetro() {
        return 2 * (base + altura);
    }
}
