public class TrianguloRectangulo {
    int base;
    int altura;

    // Constructor
    public TrianguloRectangulo(int base, int altura) {
        this.base = base;
        this.altura = altura;
    }

    // Método con retorno: calcula el área del triángulo
    public double calcularArea() {
        return (base * altura) / 2.0;
    }

    // Método con retorno: calcula la hipotenusa usando el teorema de Pitágoras
    public double calcularHipotenusa() {
        return Math.sqrt(Math.pow(base, 2) + Math.pow(altura, 2));
    }

    // Método con retorno: calcula el perímetro del triángulo rectángulo
    public double calcularPerimetro() {
        return base + altura + calcularHipotenusa();
    }

    // Método sin retorno: determina e imprime el tipo de triángulo
    public void determinarTipoTriangulo() {
        double hipotenusa = calcularHipotenusa();

        if (base == altura && base == hipotenusa) {
            System.out.println("El triángulo es Equilátero (todos sus lados son iguales).");
        } else if (base == altura || base == hipotenusa || altura == hipotenusa) {
            System.out.println("El triángulo es Isósceles (tiene dos lados iguales).");
        } else {
            System.out.println("El triángulo es Escaleno (todos sus lados son diferentes).");
        }
    }
}
