public class Cuadrado {
    int lado;

    // Constructor
    public Cuadrado(int lado) {
        this.lado = lado;
    }

    // Método con retorno: calcula el área del cuadrado
    public double calcularArea() {
        return Math.pow(lado, 2);
    }

    // Método con retorno: calcula el perímetro del cuadrado
    public double calcularPerimetro() {
        return 4 * lado;
    }
}
